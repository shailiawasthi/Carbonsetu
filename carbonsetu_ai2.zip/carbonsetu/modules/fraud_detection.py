"""
Fraud Detection System
Compares farmer-reported inputs vs satellite-derived data
and produces a Verification Risk Score.
"""


def compute_risk_score(farm_inputs: dict, satellite_data: dict) -> dict:
    """
    Returns risk score 0–100 and list of flags.
    0–30: Low Risk ✅
    31–60: Medium Risk ⚠️
    61–100: High Risk 🔴
    """
    score = 0
    flags = []
    notes = []

    ndvi = satellite_data["current_ndvi"]
    ndvi_trend = satellite_data["ndvi_trend"]
    tree_cover = farm_inputs["tree_cover"]
    practice = farm_inputs["practice"]
    fertilizer = farm_inputs["fertilizer"]
    farm_size = farm_inputs["farm_size"]

    # Check 1: Tree cover vs NDVI mismatch
    expected_ndvi_for_trees = 0.2 + (tree_cover / 100) * 0.5
    ndvi_gap = tree_cover / 100 - ndvi
    if tree_cover > 50 and ndvi < 0.3:
        score += 30
        flags.append("High tree cover claimed but satellite shows low vegetation.")
    elif tree_cover > 30 and ndvi < 0.2:
        score += 20
        flags.append("Moderate tree cover claimed but NDVI is very low.")
    else:
        notes.append("Tree cover claim consistent with satellite NDVI.")

    # Check 2: Agroforestry practice vs vegetation
    if practice == "Agroforestry" and ndvi < 0.25:
        score += 25
        flags.append("Agroforestry practice claimed but vegetation health is poor.")
    elif practice == "Agroforestry" and ndvi >= 0.5:
        notes.append("Agroforestry claim strongly supported by satellite data.")

    # Check 3: Declining NDVI trend with sustainability claims
    if ndvi_trend < -0.05 and practice in ["Agroforestry", "No-till", "Cover Cropping"]:
        score += 20
        flags.append("Sustainable practice claimed but vegetation shows declining trend.")
    elif ndvi_trend > 0.03:
        notes.append("Positive vegetation growth trend detected — supports claims.")

    # Check 4: Organic farming with very high yield expectations
    if fertilizer == "Organic only" and farm_size > 15 and ndvi < 0.3:
        score += 10
        flags.append("Large organic farm claimed with low observed vegetation density.")

    # Check 5: Healthy NDVI bonus (reduces suspicion)
    if ndvi > 0.6:
        score = max(0, score - 10)
        notes.append("High NDVI strongly validates land-use claims.")

    score = min(100, max(0, score))

    if score <= 30:
        risk_level = "Low Risk"
        risk_emoji = "✅"
        risk_color = "#22c55e"
    elif score <= 60:
        risk_level = "Medium Risk"
        risk_emoji = "⚠️"
        risk_color = "#f59e0b"
    else:
        risk_level = "High Risk"
        risk_emoji = "🔴"
        risk_color = "#ef4444"

    return {
        "score": score,
        "risk_level": risk_level,
        "risk_emoji": risk_emoji,
        "risk_color": risk_color,
        "flags": flags,
        "notes": notes,
        "verified": score <= 40,
    }
