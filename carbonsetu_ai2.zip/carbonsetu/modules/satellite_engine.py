"""
Satellite Verification Engine
Uses demo/mock mode by default. Toggle USE_GEE=True + authenticate for real data.
"""

import numpy as np
import pandas as pd

USE_GEE = False  # Set True after: earthengine authenticate


def get_ndvi_demo(lat: float, lon: float, farm_size: float):
    """
    Mock NDVI data based on location + farm size.
    Simulates realistic seasonal variation.
    """
    np.random.seed(int(abs(lat * 100 + lon * 10)) % 9999)

    base_ndvi = 0.35 + (farm_size / 50) * 0.2 + np.random.uniform(-0.1, 0.15)
    base_ndvi = np.clip(base_ndvi, 0.1, 0.85)

    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    seasonal = np.sin(np.linspace(0, 2 * np.pi, 12)) * 0.15
    ndvi_series = [round(base_ndvi + s + np.random.uniform(-0.03, 0.03), 3) for s in seasonal]
    ndvi_series = [max(0.05, min(0.9, v)) for v in ndvi_series]

    yearly = []
    for yr in range(2020, 2025):
        trend = (yr - 2020) * 0.01 + np.random.uniform(-0.02, 0.02)
        yearly.append({"year": yr, "mean_ndvi": round(base_ndvi + trend, 3)})

    ndvi_trend = yearly[-1]["mean_ndvi"] - yearly[0]["mean_ndvi"]

    return {
        "current_ndvi": round(base_ndvi, 3),
        "ndvi_trend": round(ndvi_trend, 3),
        "monthly_series": dict(zip(months, ndvi_series)),
        "yearly_series": yearly,
        "data_source": "Demo/Synthetic (GEE not connected)",
        "lat": lat,
        "lon": lon,
    }


def get_ndvi_real(lat: float, lon: float, farm_size: float):
    """Real GEE-based NDVI retrieval. Requires earthengine authenticate."""
    try:
        import ee
        ee.Initialize()

        point = ee.Geometry.Point([lon, lat])
        region = point.buffer(farm_size * 50)

        s2 = (ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
              .filterBounds(region)
              .filterDate("2023-01-01", "2024-01-01")
              .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 20))
              .map(lambda img: img.normalizedDifference(["B8", "B4"]).rename("NDVI")))

        mean_ndvi = s2.mean().reduceRegion(
            reducer=ee.Reducer.mean(), geometry=region, scale=10
        ).getInfo().get("NDVI", 0.3)

        return {
            "current_ndvi": round(mean_ndvi, 3),
            "ndvi_trend": 0.02,
            "monthly_series": {},
            "yearly_series": [],
            "data_source": "Sentinel-2 via Google Earth Engine",
            "lat": lat,
            "lon": lon,
        }
    except Exception as e:
        return get_ndvi_demo(lat, lon, farm_size)


def get_satellite_data(lat: float, lon: float, farm_size: float):
    if USE_GEE:
        return get_ndvi_real(lat, lon, farm_size)
    return get_ndvi_demo(lat, lon, farm_size)


def get_vegetation_class(ndvi: float):
    if ndvi < 0.2:
        return "Sparse / Bare Land", "🟤"
    elif ndvi < 0.35:
        return "Low Vegetation", "🟡"
    elif ndvi < 0.55:
        return "Moderate Vegetation", "🟢"
    else:
        return "Dense / Healthy Vegetation", "💚"
