"""
Explainable AI Dashboard
Uses SHAP to show which farm factors drove the carbon prediction.
"""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px


def get_shap_values(model, feature_values, feature_names):
    """Compute SHAP values using TreeExplainer."""
    try:
        import shap
        explainer = shap.TreeExplainer(model)
        shap_vals = explainer.shap_values(feature_values)
        if isinstance(shap_vals, list):
            shap_vals = shap_vals[0]
        return shap_vals[0], explainer.expected_value
    except Exception:
        # Fallback: use feature importances as proxy
        importances = model.feature_importances_
        vals = (importances / importances.sum()) * 200 - 100
        return vals, 500.0


def make_shap_bar_chart(shap_values, feature_names, feature_values_row):
    """Returns a Plotly figure showing SHAP waterfall-style bar chart."""
    pairs = sorted(zip(feature_names, shap_values, feature_values_row.values[0]),
                   key=lambda x: abs(x[1]), reverse=True)

    names = [p[0] for p in pairs]
    vals = [p[1] for p in pairs]
    raw = [p[2] for p in pairs]

    colors = ["#22c55e" if v > 0 else "#ef4444" for v in vals]
    labels = [f"{v:+.1f}" for v in vals]

    fig = go.Figure(go.Bar(
        x=vals,
        y=names,
        orientation="h",
        marker_color=colors,
        text=labels,
        textposition="outside",
        hovertemplate="<b>%{y}</b><br>SHAP impact: %{x:.2f}<extra></extra>",
    ))

    fig.update_layout(
        title="Feature Impact on Carbon Score (SHAP)",
        xaxis_title="Impact on Prediction (kg CO₂/ha)",
        yaxis=dict(autorange="reversed"),
        plot_bgcolor="#0f172a",
        paper_bgcolor="#0f172a",
        font=dict(color="#e2e8f0", family="monospace"),
        height=380,
        margin=dict(l=160, r=60, t=50, b=40),
    )
    return fig


def make_ndvi_chart(monthly_series: dict):
    """NDVI monthly line chart."""
    months = list(monthly_series.keys())
    values = list(monthly_series.values())

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=months, y=values,
        mode="lines+markers",
        line=dict(color="#4ade80", width=2.5),
        marker=dict(size=7, color="#22c55e"),
        fill="tozeroy",
        fillcolor="rgba(34,197,94,0.1)",
        name="NDVI",
        hovertemplate="<b>%{x}</b>: NDVI %{y:.3f}<extra></extra>",
    ))

    fig.add_hline(y=0.3, line_dash="dash", line_color="#f59e0b",
                  annotation_text="Low threshold (0.3)", annotation_position="bottom right")
    fig.add_hline(y=0.55, line_dash="dash", line_color="#4ade80",
                  annotation_text="Healthy (0.55)", annotation_position="top right")

    fig.update_layout(
        title="Monthly NDVI — Vegetation Health",
        yaxis=dict(title="NDVI", range=[0, 1]),
        plot_bgcolor="#0f172a",
        paper_bgcolor="#0f172a",
        font=dict(color="#e2e8f0", family="monospace"),
        height=300,
        margin=dict(l=60, r=30, t=50, b=40),
    )
    return fig


def make_yearly_ndvi_chart(yearly_series: list):
    """NDVI yearly trend bar chart."""
    if not yearly_series:
        return None
    years = [str(r["year"]) for r in yearly_series]
    vals = [r["mean_ndvi"] for r in yearly_series]

    fig = go.Figure(go.Bar(
        x=years, y=vals,
        marker_color=["#4ade80" if v > 0.4 else "#f59e0b" for v in vals],
        hovertemplate="<b>%{x}</b>: %{y:.3f}<extra></extra>",
    ))
    fig.update_layout(
        title="Annual NDVI Trend (2020–2024)",
        yaxis=dict(title="Mean NDVI", range=[0, 1]),
        plot_bgcolor="#0f172a",
        paper_bgcolor="#0f172a",
        font=dict(color="#e2e8f0", family="monospace"),
        height=280,
        margin=dict(l=60, r=30, t=50, b=40),
    )
    return fig


def make_gauge(score: int, color: str):
    """Risk score gauge chart."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score,
        title={"text": "Verification Risk Score", "font": {"color": "#e2e8f0", "size": 14}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": "#64748b"},
            "bar": {"color": color},
            "bgcolor": "#1e293b",
            "steps": [
                {"range": [0, 30], "color": "#14532d"},
                {"range": [30, 60], "color": "#713f12"},
                {"range": [60, 100], "color": "#7f1d1d"},
            ],
            "threshold": {"line": {"color": "white", "width": 3}, "thickness": 0.8, "value": score},
        },
        number={"font": {"color": color, "size": 36}},
    ))
    fig.update_layout(
        paper_bgcolor="#0f172a",
        font=dict(color="#e2e8f0"),
        height=260,
        margin=dict(l=30, r=30, t=50, b=20),
    )
    return fig


def make_projection_chart(total_tonnes: float, years: int = 5):
    """Multi-year carbon projection."""
    growth_rate = 0.05
    yr = list(range(1, years + 1))
    tonnes = [round(total_tonnes * ((1 + growth_rate) ** (y - 1)), 2) for y in yr]
    earnings = [round(t * 800, 0) for t in tonnes]

    fig = go.Figure()
    fig.add_trace(go.Bar(x=yr, y=tonnes, name="Carbon Tonnes", marker_color="#4ade80",
                         hovertemplate="Year %{x}: %{y:.2f} tonnes<extra></extra>"))
    fig.add_trace(go.Scatter(x=yr, y=earnings, name="Earnings (₹)", mode="lines+markers",
                             yaxis="y2", line=dict(color="#facc15", width=2),
                             hovertemplate="Year %{x}: ₹%{y:,.0f}<extra></extra>"))

    fig.update_layout(
        title="5-Year Carbon Credit Projection",
        xaxis_title="Year",
        yaxis=dict(title="Tonnes CO₂", color="#4ade80"),
        yaxis2=dict(title="Earnings (₹)", overlaying="y", side="right", color="#facc15"),
        plot_bgcolor="#0f172a",
        paper_bgcolor="#0f172a",
        font=dict(color="#e2e8f0", family="monospace"),
        legend=dict(bgcolor="#1e293b"),
        height=300,
        margin=dict(l=60, r=80, t=50, b=40),
    )
    return fig
