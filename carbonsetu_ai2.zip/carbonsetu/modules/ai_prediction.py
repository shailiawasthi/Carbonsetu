"""
AI Prediction Engine — trains Random Forest & XGBoost models
and predicts carbon sequestration from farm inputs.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb
import joblib
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "carbon_model.pkl")
ENCODER_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "encoders.pkl")

CROP_TYPES = ["Rice", "Wheat", "Maize", "Sugarcane", "Cotton", "Soybean", "Pulses", "Vegetables", "Fruits", "Agroforestry"]
IRRIGATION = ["Rainfed", "Canal", "Drip", "Sprinkler", "Borewell"]
FERTILIZER = ["Chemical only", "Mixed", "Organic only", "None"]
PRACTICES = ["Conventional", "Crop Rotation", "Agroforestry", "No-till", "Cover Cropping", "Integrated Farming"]

CARBON_PRICE_INR = 800  # per tonne CO2


def generate_synthetic_data(n=2000):
    """Generate synthetic training data for the carbon model."""
    np.random.seed(42)
    records = []
    for _ in range(n):
        crop = np.random.choice(CROP_TYPES)
        irrigation = np.random.choice(IRRIGATION)
        fertilizer = np.random.choice(FERTILIZER)
        practice = np.random.choice(PRACTICES)
        farm_size = np.random.uniform(0.5, 20)
        tree_cover = np.random.uniform(0, 80)
        ndvi = np.random.uniform(0.1, 0.85)
        ndvi_trend = np.random.uniform(-0.1, 0.2)

        # Base sequestration logic (kg CO2/ha/year)
        base = 500
        if practice == "Agroforestry": base += 1200
        elif practice == "No-till": base += 600
        elif practice == "Crop Rotation": base += 400
        elif practice == "Cover Cropping": base += 350
        elif practice == "Integrated Farming": base += 500

        if fertilizer == "Organic only": base += 300
        elif fertilizer == "Mixed": base += 150
        elif fertilizer == "Chemical only": base -= 100

        if irrigation == "Drip": base += 100
        if crop == "Agroforestry": base += 800
        if crop in ["Fruits", "Pulses"]: base += 200

        base += tree_cover * 15
        base += ndvi * 800
        base += ndvi_trend * 500
        base += np.random.normal(0, 80)
        base = max(100, base)

        records.append({
            "farm_size": farm_size,
            "tree_cover": tree_cover,
            "ndvi": ndvi,
            "ndvi_trend": ndvi_trend,
            "crop_type": crop,
            "irrigation": irrigation,
            "fertilizer": fertilizer,
            "practice": practice,
            "carbon_kg_per_ha": base,
        })
    return pd.DataFrame(records)


def train_model():
    """Train and save the carbon prediction model."""
    df = generate_synthetic_data(2000)

    le_crop = LabelEncoder().fit(CROP_TYPES)
    le_irr = LabelEncoder().fit(IRRIGATION)
    le_fert = LabelEncoder().fit(FERTILIZER)
    le_prac = LabelEncoder().fit(PRACTICES)

    df["crop_enc"] = le_crop.transform(df["crop_type"])
    df["irr_enc"] = le_irr.transform(df["irrigation"])
    df["fert_enc"] = le_fert.transform(df["fertilizer"])
    df["prac_enc"] = le_prac.transform(df["practice"])

    features = ["farm_size", "tree_cover", "ndvi", "ndvi_trend", "crop_enc", "irr_enc", "fert_enc", "prac_enc"]
    X = df[features]
    y = df["carbon_kg_per_ha"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = xgb.XGBRegressor(n_estimators=200, max_depth=6, learning_rate=0.05, random_state=42)
    model.fit(X_train, y_train)

    encoders = {"crop": le_crop, "irrigation": le_irr, "fertilizer": le_fert, "practice": le_prac}
    joblib.dump(model, MODEL_PATH)
    joblib.dump(encoders, ENCODER_PATH)
    return model, encoders


def load_or_train():
    if os.path.exists(MODEL_PATH) and os.path.exists(ENCODER_PATH):
        return joblib.load(MODEL_PATH), joblib.load(ENCODER_PATH)
    return train_model()


def predict(farm_inputs: dict):
    """
    farm_inputs: dict with keys:
      farm_size, tree_cover, ndvi, ndvi_trend,
      crop_type, irrigation, fertilizer, practice
    Returns dict with prediction results.
    """
    model, encoders = load_or_train()

    X = pd.DataFrame([{
        "farm_size": farm_inputs["farm_size"],
        "tree_cover": farm_inputs["tree_cover"],
        "ndvi": farm_inputs["ndvi"],
        "ndvi_trend": farm_inputs["ndvi_trend"],
        "crop_enc": encoders["crop"].transform([farm_inputs["crop_type"]])[0],
        "irr_enc": encoders["irrigation"].transform([farm_inputs["irrigation"]])[0],
        "fert_enc": encoders["fertilizer"].transform([farm_inputs["fertilizer"]])[0],
        "prac_enc": encoders["practice"].transform([farm_inputs["practice"]])[0],
    }])

    carbon_per_ha = float(model.predict(X)[0])
    total_carbon_kg = carbon_per_ha * farm_inputs["farm_size"]
    total_carbon_tonnes = total_carbon_kg / 1000
    credits = total_carbon_tonnes  # 1 credit = 1 tonne CO2
    earnings_inr = credits * CARBON_PRICE_INR

    return {
        "carbon_per_ha_kg": round(carbon_per_ha, 1),
        "total_carbon_tonnes": round(total_carbon_tonnes, 2),
        "carbon_credits": round(credits, 2),
        "earnings_inr": round(earnings_inr, 0),
        "feature_values": X,
        "model": model,
    }


def get_feature_names():
    return ["Farm Size (ha)", "Tree Cover (%)", "NDVI", "NDVI Trend", "Crop Type", "Irrigation", "Fertilizer", "Practice"]
