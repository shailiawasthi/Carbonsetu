# 🌿 CarbonSetu AI 2.0

**AI-Driven Carbon Credit Verification & Prediction Platform for Smallholder Farms**

---

## 🚀 Quick Start (Local)

### 1. Install Python 3.9+
Download from https://python.org if not already installed.

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
streamlit run app.py
```
Your browser will open at `http://localhost:8501` automatically.

---

## 📁 Project Structure

```
carbonsetu/
├── app.py                    ← Main Streamlit app (run this)
├── requirements.txt          ← All Python dependencies
├── modules/
│   ├── ai_prediction.py      ← XGBoost carbon prediction model
│   ├── satellite_engine.py   ← NDVI / satellite data (demo + GEE)
│   ├── fraud_detection.py    ← Verification risk scoring
│   └── xai_dashboard.py     ← SHAP explainability charts
└── models/                   ← Saved model files (auto-generated)
```

---

## 🌍 Enable Real Satellite Data (Optional)

1. Sign up at https://earthengine.google.com (free for research)
2. In your terminal: `earthengine authenticate`
3. Open `modules/satellite_engine.py` and set:
   ```python
   USE_GEE = True
   ```

---

## ☁️ Deploy Online (Free)

### Streamlit Cloud (Easiest)
1. Push this folder to a GitHub repository
2. Go to https://share.streamlit.io
3. Connect your repo → select `app.py` → Deploy

### Hugging Face Spaces
1. Create a Space at https://huggingface.co/spaces
2. Choose "Streamlit" as the SDK
3. Upload all files

---

## 🛠️ Tech Stack

| Component | Technology |
|---|---|
| UI | Streamlit |
| AI Model | XGBoost + Scikit-learn |
| Explainability | SHAP |
| Charts | Plotly |
| Satellite (demo) | Synthetic NDVI |
| Satellite (real) | Google Earth Engine + Sentinel-2 |

---

## ⚠️ Disclaimer
This is a research/prototype tool. Demo mode uses synthetic satellite data.
Not intended for commercial carbon credit trading without validation.

---

Built with CarbonSetu AI 2.0 · MIT License
