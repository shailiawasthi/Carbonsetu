"""
CarbonSetu AI 2.0 — Main Streamlit Application
AI-Driven Carbon Credit Verification & Prediction for Smallholder Farms
"""

import streamlit as st
import pandas as pd
import numpy as np

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CarbonSetu AI 2.0",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
    background-color: #0a0f1e;
    color: #e2e8f0;
}

.stApp { background: linear-gradient(135deg, #0a0f1e 0%, #0d1f14 60%, #0a0f1e 100%); }

h1, h2, h3 { font-family: 'Syne', sans-serif; font-weight: 800; }

.hero-title {
    font-family: 'Syne', sans-serif;
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(90deg, #4ade80, #22d3ee, #4ade80);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.1;
    margin-bottom: 0.2rem;
}

.hero-sub {
    color: #94a3b8;
    font-size: 1rem;
    font-family: 'Space Mono', monospace;
    margin-bottom: 1.5rem;
    letter-spacing: 0.02em;
}

.metric-card {
    background: linear-gradient(135deg, #0f2027, #1a3a2a);
    border: 1px solid #22c55e33;
    border-radius: 12px;
    padding: 1.2rem 1.5rem;
    text-align: center;
    box-shadow: 0 0 20px #22c55e11;
}

.metric-value {
    font-family: 'Space Mono', monospace;
    font-size: 1.8rem;
    font-weight: 700;
    color: #4ade80;
}

.metric-label {
    font-size: 0.78rem;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-top: 0.3rem;
}

.section-header {
    font-family: 'Space Mono', monospace;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: #4ade80;
    border-left: 3px solid #4ade80;
    padding-left: 0.7rem;
    margin: 1.5rem 0 0.8rem 0;
}

.flag-box {
    background: #3f0f0f;
    border: 1px solid #ef444455;
    border-radius: 8px;
    padding: 0.6rem 1rem;
    margin: 0.3rem 0;
    font-size: 0.88rem;
    color: #fca5a5;
}

.note-box {
    background: #0f2f1a;
    border: 1px solid #22c55e44;
    border-radius: 8px;
    padding: 0.6rem 1rem;
    margin: 0.3rem 0;
    font-size: 0.88rem;
    color: #86efac;
}

.badge-demo {
    background: #1e3a5f;
    border: 1px solid #3b82f6;
    border-radius: 20px;
    padding: 0.2rem 0.8rem;
    font-family: 'Space Mono', monospace;
    font-size: 0.72rem;
    color: #93c5fd;
    display: inline-block;
    margin-bottom: 1rem;
}

div[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1a0f, #0a1520);
    border-right: 1px solid #1a2e1a;
}

.stButton > button {
    background: linear-gradient(135deg, #166534, #15803d);
    color: white;
    border: none;
    border-radius: 8px;
    font-family: 'Space Mono', monospace;
    font-size: 0.85rem;
    font-weight: 700;
    padding: 0.6rem 1.5rem;
    width: 100%;
    transition: all 0.2s ease;
    letter-spacing: 0.05em;
}

.stButton > button:hover {
    background: linear-gradient(135deg, #15803d, #16a34a);
    box-shadow: 0 0 20px #22c55e44;
    transform: translateY(-1px);
}

.stSelectbox label, .stSlider label, .stNumberInput label {
    color: #94a3b8 !important;
    font-size: 0.82rem !important;
    font-family: 'Space Mono', monospace !important;
}

.stTabs [data-baseweb="tab"] {
    font-family: 'Space Mono', monospace;
    font-size: 0.8rem;
    color: #64748b;
}

.stTabs [aria-selected="true"] {
    color: #4ade80 !important;
}

hr { border-color: #1e293b; }

.verified-chip {
    display: inline-block;
    padding: 0.3rem 1rem;
    border-radius: 20px;
    font-family: 'Space Mono', monospace;
    font-size: 0.8rem;
    font-weight: 700;
}
</style>
""", unsafe_allow_html=True)

# ── Imports ────────────────────────────────────────────────────────────────────
from modules.ai_prediction import (
    predict, CROP_TYPES, IRRIGATION, FERTILIZER, PRACTICES, get_feature_names
)
from modules.satellite_engine import get_satellite_data, get_vegetation_class
from modules.fraud_detection import compute_risk_score
from modules.xai_dashboard import (
    get_shap_values, make_shap_bar_chart, make_ndvi_chart,
    make_yearly_ndvi_chart, make_gauge, make_projection_chart
)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="hero-title" style="font-size:1.6rem;">🌿 CarbonSetu</div>', unsafe_allow_html=True)
    st.markdown('<div class="hero-sub" style="font-size:0.75rem;">AI 2.0 · Carbon Credit Platform</div>', unsafe_allow_html=True)
    st.markdown('<div class="badge-demo">● DEMO MODE</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-header">Farm Location</div>', unsafe_allow_html=True)
    lat = st.number_input("Latitude", value=20.59, format="%.4f", min_value=-90.0, max_value=90.0)
    lon = st.number_input("Longitude", value=78.96, format="%.4f", min_value=-180.0, max_value=180.0)

    st.markdown('<div class="section-header">Farm Details</div>', unsafe_allow_html=True)
    farm_size = st.slider("Farm Size (hectares)", 0.5, 20.0, 3.0, 0.5)
    crop_type = st.selectbox("Crop Type", CROP_TYPES)
    tree_cover = st.slider("Tree Cover (%)", 0, 80, 20)

    st.markdown('<div class="section-header">Farming Practices</div>', unsafe_allow_html=True)
    irrigation = st.selectbox("Irrigation Method", IRRIGATION)
    fertilizer = st.selectbox("Fertilizer Type", FERTILIZER)
    practice = st.selectbox("Farming Practice", PRACTICES)

    st.markdown("")
    run = st.button("🔍 Analyse My Farm")

# ── Hero Header ────────────────────────────────────────────────────────────────
st.markdown('<div class="hero-title">CarbonSetu AI 2.0</div>', unsafe_allow_html=True)
st.markdown('<div class="hero-sub">AI-Driven Carbon Credit Verification & Prediction · Smallholder Farms</div>', unsafe_allow_html=True)

# ── Default state ──────────────────────────────────────────────────────────────
if not run:
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-value">🛰️</div>
            <div class="metric-label">Satellite Verified</div>
        </div>""", unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-value">🤖</div>
            <div class="metric-label">AI Prediction Engine</div>
        </div>""", unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-value">🛡️</div>
            <div class="metric-label">Fraud Detection</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("""
    <br>
    <div style="color:#475569; font-family:'Space Mono',monospace; font-size:0.8rem; text-align:center;">
    ← Fill in your farm details in the sidebar and click <b style="color:#4ade80;">Analyse My Farm</b> to begin
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── Run Analysis ───────────────────────────────────────────────────────────────
farm_inputs = {
    "farm_size": farm_size,
    "tree_cover": tree_cover,
    "crop_type": crop_type,
    "irrigation": irrigation,
    "fertilizer": fertilizer,
    "practice": practice,
}

with st.spinner("Fetching satellite data..."):
    sat = get_satellite_data(lat, lon, farm_size)

farm_inputs["ndvi"] = sat["current_ndvi"]
farm_inputs["ndvi_trend"] = sat["ndvi_trend"]

with st.spinner("Running AI prediction..."):
    pred = predict(farm_inputs)

with st.spinner("Computing risk score..."):
    risk = compute_risk_score(farm_inputs, sat)

veg_class, veg_emoji = get_vegetation_class(sat["current_ndvi"])

# ── Summary Metrics ────────────────────────────────────────────────────────────
st.markdown("---")
c1, c2, c3, c4, c5 = st.columns(5)

with c1:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value">{sat['current_ndvi']}</div>
        <div class="metric-label">Current NDVI</div>
    </div>""", unsafe_allow_html=True)

with c2:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value">{pred['total_carbon_tonnes']}</div>
        <div class="metric-label">Tonnes CO₂/yr</div>
    </div>""", unsafe_allow_html=True)

with c3:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value">{pred['carbon_credits']}</div>
        <div class="metric-label">Carbon Credits</div>
    </div>""", unsafe_allow_html=True)

with c4:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value">₹{int(pred['earnings_inr']):,}</div>
        <div class="metric-label">Est. Earnings/yr</div>
    </div>""", unsafe_allow_html=True)

with c5:
    chip_color = risk["risk_color"]
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value" style="color:{chip_color}">{risk['score']}/100</div>
        <div class="metric-label">Risk Score</div>
    </div>""", unsafe_allow_html=True)

st.markdown("")

# ── Tabs ───────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs([
    "🛰️  Satellite Data",
    "🤖  AI Prediction",
    "🛡️  Fraud Detection",
    "📊  Explainability"
])

# ── TAB 1: Satellite ───────────────────────────────────────────────────────────
with tab1:
    st.markdown('<div class="section-header">Vegetation Health Overview</div>', unsafe_allow_html=True)

    col_a, col_b = st.columns([1, 2])
    with col_a:
        trend_arrow = "📈" if sat["ndvi_trend"] > 0 else "📉"
        st.markdown(f"""
        <div class="metric-card" style="text-align:left; margin-bottom:1rem;">
            <div style="font-family:'Space Mono',monospace; font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:0.1em;">Vegetation Class</div>
            <div style="font-size:1.3rem; font-weight:700; color:#4ade80; margin:0.5rem 0;">{veg_emoji} {veg_class}</div>
            <hr style="border-color:#1e293b; margin:0.7rem 0;">
            <div style="font-family:'Space Mono',monospace; font-size:0.78rem; color:#94a3b8;">
                NDVI: <b style="color:#4ade80;">{sat['current_ndvi']}</b><br>
                5yr Trend: <b style="color:{'#4ade80' if sat['ndvi_trend']>0 else '#ef4444'};">{trend_arrow} {sat['ndvi_trend']:+.3f}</b><br>
                Location: <b style="color:#e2e8f0;">{lat:.2f}°N, {lon:.2f}°E</b><br>
                Source: <b style="color:#93c5fd;">{sat['data_source']}</b>
            </div>
        </div>""", unsafe_allow_html=True)

    with col_b:
        if sat["monthly_series"]:
            st.plotly_chart(make_ndvi_chart(sat["monthly_series"]), use_container_width=True)

    if sat["yearly_series"]:
        st.plotly_chart(make_yearly_ndvi_chart(sat["yearly_series"]), use_container_width=True)

# ── TAB 2: AI Prediction ───────────────────────────────────────────────────────
with tab2:
    st.markdown('<div class="section-header">Carbon Sequestration Prediction</div>', unsafe_allow_html=True)

    col_p1, col_p2 = st.columns(2)
    with col_p1:
        st.markdown(f"""
        <div class="metric-card" style="text-align:left;">
            <div style="font-family:'Space Mono',monospace; font-size:0.72rem; color:#64748b; letter-spacing:0.1em; text-transform:uppercase;">Prediction Breakdown</div>
            <br>
            <table style="width:100%; font-family:'Space Mono',monospace; font-size:0.82rem; color:#94a3b8; border-collapse:collapse;">
            <tr><td style="padding:4px 0;">Carbon per hectare</td><td style="color:#4ade80; text-align:right;">{pred['carbon_per_ha_kg']:,} kg/ha</td></tr>
            <tr><td style="padding:4px 0;">Total carbon (farm)</td><td style="color:#4ade80; text-align:right;">{pred['total_carbon_tonnes']} tonnes</td></tr>
            <tr><td style="padding:4px 0;">Carbon credits</td><td style="color:#facc15; text-align:right;">{pred['carbon_credits']} credits</td></tr>
            <tr><td style="padding:4px 0;">Carbon price</td><td style="color:#e2e8f0; text-align:right;">₹800 / tonne</td></tr>
            <tr style="border-top:1px solid #1e293b;"><td style="padding:8px 0; font-weight:700; color:#e2e8f0;">Estimated Earnings</td><td style="color:#4ade80; font-size:1.1rem; font-weight:700; text-align:right;">₹{int(pred['earnings_inr']):,}</td></tr>
            </table>
        </div>""", unsafe_allow_html=True)

    with col_p2:
        st.markdown(f"""
        <div class="metric-card" style="text-align:left;">
            <div style="font-family:'Space Mono',monospace; font-size:0.72rem; color:#64748b; letter-spacing:0.1em; text-transform:uppercase;">Farm Summary</div>
            <br>
            <table style="width:100%; font-family:'Space Mono',monospace; font-size:0.82rem; color:#94a3b8; border-collapse:collapse;">
            <tr><td style="padding:4px 0;">Farm size</td><td style="color:#e2e8f0; text-align:right;">{farm_size} ha</td></tr>
            <tr><td style="padding:4px 0;">Crop type</td><td style="color:#e2e8f0; text-align:right;">{crop_type}</td></tr>
            <tr><td style="padding:4px 0;">Practice</td><td style="color:#4ade80; text-align:right;">{practice}</td></tr>
            <tr><td style="padding:4px 0;">Irrigation</td><td style="color:#e2e8f0; text-align:right;">{irrigation}</td></tr>
            <tr><td style="padding:4px 0;">Fertilizer</td><td style="color:#e2e8f0; text-align:right;">{fertilizer}</td></tr>
            <tr><td style="padding:4px 0;">Tree cover</td><td style="color:#e2e8f0; text-align:right;">{tree_cover}%</td></tr>
            </table>
        </div>""", unsafe_allow_html=True)

    st.markdown("")
    st.plotly_chart(make_projection_chart(pred["total_carbon_tonnes"]), use_container_width=True)

# ── TAB 3: Fraud Detection ─────────────────────────────────────────────────────
with tab3:
    st.markdown('<div class="section-header">Verification Risk Assessment</div>', unsafe_allow_html=True)

    col_r1, col_r2 = st.columns([1, 1])
    with col_r1:
        st.plotly_chart(make_gauge(risk["score"], risk["risk_color"]), use_container_width=True)

        verified_text = "VERIFIED ✅" if risk["verified"] else "FLAGGED FOR REVIEW ⚠️"
        chip_bg = "#14532d" if risk["verified"] else "#713f12"
        st.markdown(f"""
        <div style="text-align:center; margin-top:0.5rem;">
            <span class="verified-chip" style="background:{chip_bg}; color:{'#4ade80' if risk['verified'] else '#fbbf24'}; border:1px solid {'#22c55e' if risk['verified'] else '#f59e0b'};">
                {verified_text}
            </span>
        </div>""", unsafe_allow_html=True)

    with col_r2:
        st.markdown(f'<div class="section-header">Risk Level: {risk["risk_emoji"]} {risk["risk_level"]}</div>', unsafe_allow_html=True)

        if risk["flags"]:
            st.markdown("**Issues Detected:**")
            for f in risk["flags"]:
                st.markdown(f'<div class="flag-box">⚠ {f}</div>', unsafe_allow_html=True)

        if risk["notes"]:
            st.markdown("**Positive Signals:**")
            for n in risk["notes"]:
                st.markdown(f'<div class="note-box">✓ {n}</div>', unsafe_allow_html=True)

        if not risk["flags"] and not risk["notes"]:
            st.markdown('<div class="note-box">✓ No significant anomalies detected.</div>', unsafe_allow_html=True)

# ── TAB 4: Explainability ──────────────────────────────────────────────────────
with tab4:
    st.markdown('<div class="section-header">SHAP — Why did the AI give this score?</div>', unsafe_allow_html=True)

    with st.spinner("Computing SHAP values..."):
        shap_vals, base_val = get_shap_values(
            pred["model"], pred["feature_values"], get_feature_names()
        )

    st.plotly_chart(
        make_shap_bar_chart(shap_vals, get_feature_names(), pred["feature_values"]),
        use_container_width=True
    )

    st.markdown(f"""
    <div style="font-family:'Space Mono',monospace; font-size:0.78rem; color:#64748b; margin-top:0.5rem;">
    Base prediction (model average): <b style="color:#94a3b8;">{base_val:.0f} kg CO₂/ha</b> &nbsp;|&nbsp;
    Your farm prediction: <b style="color:#4ade80;">{pred['carbon_per_ha_kg']:,} kg CO₂/ha</b><br><br>
    Green bars = factors that <b style="color:#4ade80;">increased</b> your carbon score. 
    Red bars = factors that <b style="color:#ef4444;">reduced</b> it.
    </div>
    """, unsafe_allow_html=True)

# ── Footer ─────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="font-family:'Space Mono',monospace; font-size:0.68rem; color:#334155; text-align:center;">
CarbonSetu AI 2.0 · Demo Mode · Satellite data is simulated · Not for commercial carbon trading
</div>
""", unsafe_allow_html=True)
